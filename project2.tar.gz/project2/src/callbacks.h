#include <gtk/gtk.h>


void
on_Add_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_Delete_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Edit_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Search_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Exit_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Next_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_Prev_clicked                        (GtkButton       *button,
                                        gpointer         user_data);
